

//A class defining the object fruit 
public class Fruit implements Comparable<Fruit> {
	//the name of the fruit
	private String name;
	//the weight of the fruit
	private double weight;
	
	public Fruit(String name, double weight){
		this.name = name;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight > 0.0)
			this.weight = weight;
	}
	public String toString(){
		return this.name+": "+this.weight;
	}

	@Override
	public int compareTo(Fruit o) {
		if (this.weight < o.weight)
			return -1;
		else if (this.weight > o.weight)
			return 1;
		return 0;
	}
	
}
