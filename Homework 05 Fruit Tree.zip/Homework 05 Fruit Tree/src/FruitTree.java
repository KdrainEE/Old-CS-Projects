import java.io.*;
import java.util.*;

public class FruitTree {
	private static final String DELIM = "\t";
	
	public static void main(String[] args){
		
		System.out.println("Welcome to the friut tree database.\n");
		//Initialize the tree 
		LinkedBSTree<Fruit> fruitTree = new LinkedBSTree();
		String fileName = "fruitFile.txt";
		
		System.out.println("Populating the tree.\n");
		
		//find the file
		Scanner fReader = null;
		try
		{
			fReader = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e)
		{
			System.err.println(e.getMessage());
		}
		//populate the tree
		for(int i=0;i<10;i++){//while (fReader.hasNextLine()){
			String entry = fReader.nextLine();
			String[] nextLine = entry.split(DELIM, -1);
			double weight = Double.parseDouble(nextLine[1]);
			
			Fruit newFruit = new Fruit(nextLine[0], weight);
			fruitTree.insert(newFruit);
		}
		
		//print in-order traversal
		System.out.println("Printing in order traversal.\n");
		fruitTree.printInOrder();
		System.out.println();
		
		//Print pre-order traversal
		System.out.println("Printing pre-order traversal.\n");
		fruitTree.printPreOrder();
		System.out.println();
		
		//delete a fruit, in this case the first item from the original file
		Fruit delFruit = new Fruit("Apple", 0.4859853412170728);
		System.out.println("Deleting "+delFruit.toString()+"\n");
		fruitTree.delete(delFruit);
		
		
		//Print post-order traversal
		System.out.println("Printing post-order traversal.\n");
		fruitTree.printPostOrder();
		
		
	}
	


}
